---
name: results-section-revision
description: Use when revising a scientific manuscript Results section whose figures, evidence, and main claims are mostly fixed, but subsection flow, paragraph openings, reader guidance, and argumentative progression still feel abrupt, repetitive, or figure-by-figure.
---

# Results Section Revision

## Overview

Use this skill for late-stage Results revision when the science is mostly stable but the writing architecture is not. It is narrower than `scientific-writing` and `manuscript-optimizer`: the job here is to repair subsection titles, bridge paragraphs, paragraph openings, and local argumentative flow.

Use `scientific-writing` for general prose drafting or rewriting. Use `manuscript-optimizer` when the claim hierarchy, evidence chain, or figure logic is still unstable. Use this skill when the section is largely right but still reads like stitched figure captions rather than a controlled argument.

## Quick Checks

Before revising any Results subsection, check:

1. Is the title selling the conclusion rather than the method?
2. Does the first sentence of each paragraph state that paragraph's point?
3. Are openings like `we asked`, `we examined`, or `to test this` overused?
4. Are abstract words masking a more specific noun?
5. Is the relationship to the previous paragraph explicit?
6. Is the paragraph only reporting a result, or advancing the argument?
7. Is the evidence boundary clear between what Results establishes and what belongs in Discussion?
8. Does each comparison identify what differs and what it establishes?
9. Is argumentative progression clear without adding a forced transition?

## Subsection Pattern

A subsection may open with rationale, observation, contrast, or result.

A closing inference is optional. Stop when the evidence unit is complete. Do not add a transition only to make the subsection feel complete.

A first paragraph may bridge from the previous subsection when that bridge is
needed; it may also begin with a direct observation, contrast, or result. Later
paragraphs should each do one job: sharpen a finding, separate related findings,
show a consequence for evaluation or prioritization, or explain what a comparison
actually distinguishes.

Subsection length follows evidence and argumentative importance. A short ablation may require one compact paragraph. A central result may require several paragraphs.

## Paragraph Openings

Prefer openings that either orient the reader or state a concrete result:

- `The molecular branch first showed ...`
- `The same pattern was also evident in ...`
- `A further question was whether ...`
- `Cross-representation analyses showed ...`

Avoid repeated procedural scaffolds:

- `To test this ...`
- `We next asked ...`
- `We then examined ...`

At the start of a new paragraph, avoid vague pronouns unless the referent is unmistakable. Replace `this structure` or `that mismatch` with the explicit noun phrase.

## Style Rules

- One paragraph, one job.
- Use explicit contrasts early.
- Surface key quantitative anchors before interpretation.
- Keep the register controlled, direct, and specific.
- Keep the evidence boundary visible: report what the data establish in Results,
  and reserve broader interpretation for Discussion when it goes beyond the
  measured result.
- Preserve the Results/Discussion distinction; do not add significance claims
  merely to close a subsection.

## Scope

Review-only: diagnose and recommend; do not rewrite unless the user explicitly
asks for rewriting.

## Common Failure Modes

- method-like subsection titles
- first paragraphs that announce a result without a rationale
- several paragraphs in a row with the same procedural opening
- abstract nouns that blur what is actually being compared
- summary sentences that restate the result but not its implication
