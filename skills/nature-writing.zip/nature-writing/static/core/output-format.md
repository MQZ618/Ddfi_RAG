# Output format (writing)

Default delivery:

Return the requested manuscript prose once.

Keep planning, detected axes, Skill activity, word-count checks, alignment
checks, and self-review internal.

Do not repeat a draft after checking it.

Do not append section outlines, assumptions, claim-evidence maps, structural explanations, revision notes, or redirect prompts unless the user explicitly requests them.

When the user specifies a word count, paragraph count, language, section type,
or output format, verify the constraint internally before delivery.

If the user explicitly requests an outline, audit, comparison, or explanation
of changes, provide only the requested addition after the prose.

If essential evidence or a boundary is missing, do not invent it; use a concise
placeholder only when it belongs to the requested prose.

For `task=submission-package`, replace the default manuscript format with:

1. `Submission readiness:`
2. `Deliverable matrix:`
3. `Draft materials:`
4. `AUTHOR_INPUT_NEEDED:`
5. `Cross-file consistency checks:`
6. `Next actions:`
