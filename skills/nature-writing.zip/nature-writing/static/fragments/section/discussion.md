# Section: Discussion (writing)

## Default structure

Discussion paragraphs may take different responsibilities, including mechanism,
boundary, relation to prior work, synthesis across Results, or future use and
open questions. Select the sequence that fits the evidence; do not force a
fixed four-step structure.

## Drafting rules

- Discussion **synthesizes across established Results claims**; it does not
  repeat the evidence figure by figure.
- Address rival explanations before generalizing. Reviewers look for this.
- Hedging strength must match evidence strength. Do not promote a "consistent with" finding to "demonstrates" wording.
- Limitations come from inside the paper, not from generic disclaimers. Name the specific condition or dataset where the result stops holding.

## Sentence syntax

Discussion sentences interpret:

- `may reflect`
- `suggests that`
- `could indicate`
- `is likely due to`
- `may facilitate`

## Common failure modes when drafting

- Re-summarizing Results instead of interpreting them.
- Skipping rival explanations.
- Omitting boundaries — when does the interpretation stop holding?
- Future-work statements that read as marketing, not as honest open questions.

## Short rule to memorize

- Results = the evidence chain that establishes and advances claims
- Discussion = what those claims mean together, how they relate to the field,
  and when the synthesis may fail
