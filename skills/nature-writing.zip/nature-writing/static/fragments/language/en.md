# Language: English source (writing)

When the source notes are already in English, default to standard scientific-English drafting conventions.

## Sentence rules

- Use sentence length as a review signal, not a hard limit. 35–40 words is a review signal, not a hard limit.
- Split only when a sentence carries multiple logical functions.
- Preserve a long sentence when its subject, relation and qualification remain clear.
- Do not split a sentence solely because the sentence occupies two or three visual lines.
- Check clusters of overloaded sentences, not isolated sentence length.
- Prefer subject-verb-object order. Avoid stacked prepositional chains.
- Avoid em dashes as prose punctuation in drafts unless the user explicitly asks. Use commas, parentheses, or short sentences.

## Paragraph rules

- Each paragraph has one controlling job, but may contain the evidence,
  qualification, comparison, or explanation needed to complete that job.
- Choose the opening that fits the argument: rationale-first, observation-first,
  contrast-first, claim-first, or limitation-first.
- Give each subsequent sentence a clear relation to the previous one: cause,
  comparison, restriction, example, or qualification.
- Split only when a second controlling job needs its own paragraph; do not split
  a paragraph merely because it contains the support needed for its first job.

## Diction

- Calibrate verbs to evidence strength (`show` / `suggest` / `may`).
- Avoid marketing verbs (`leverages`, `enables`, `empowers`) unless they carry concrete information.
- Avoid universal claims (`always`, `never`, `comprehensive`).
