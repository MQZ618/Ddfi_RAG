---
name: academic-writing-review
description: "Use when reviewing graduate-level academic prose for unsuitable thesis/report language, AI-like explanatory text, abstract concept stacking, mechanical structure, defensive wording, or mixing plans, conclusions, and risk notes（研究生学术正文审查、AI味、正文合格性检查）."
metadata:
  category: "academic-writing"
  priority: "optional"
---

# Academic Writing Review

## 目标

判断研究生开题报告、学位论文、课程论文或期刊初稿中的文字是否适合作为正式学术正文。重点是“正文合格性”，不是单纯润色。

## 首先识别文种

确认当前内容属于：
- 开题报告；
- 学位论文正文；
- 期刊论文；
- 课程论文；
- 其他科研材料。

不同文种允许的计划性、评价性和论证强度不同。

## 重点检查

逐段识别以下问题：

1. 审查报告语言进入正文；
2. 项目管理语言进入正文；
3. AI 为证明“符合要求”产生的解释性文字；
4. 抽象概念堆砌但缺少对象、变量和机制；
5. 生硬的“研究问题一对应方法一”式说明；
6. 机械排比、模板句和重复句式；
7. 反复限定、反复自我辩护；
8. 研究计划、研究结论和风险说明混写；
9. 语法正确但不适合正式正文的句子；
10. 本应放入表格、验证方案、实验记录或审查报告的内容。

### 可检索的结构与句式审查项

使用以下英文标签记录可复核的问题；标签本身不构成必须改写的理由：

- `subsection length symmetry`
- `repeated paragraph count`
- `repeated procedural opening`
- `overloaded sentence density`
- `formulaic paragraph closure`
- `unnecessary significance statement`

### 审查边界

- diagnose before rewriting
- Do not rewrite an acceptable paragraph merely to vary rhythm.
- Do not infer whole-manuscript symmetry from a partial excerpt.

## 科研逻辑检查

如果段落涉及研究论证，同时检查：

- 是否把技术难点包装成科学问题；
- 是否先有现实/科学问题，再选择技术；
- 创新点是否只是换模型、加模块或提高指标；
- 结论强度是否超过已有证据；
- 是否存在“为了显得严谨而过度解释”。

## 输出规则

输出必须区分为以下三类，不能混为一谈：

【必须修改】影响正文合法性、逻辑或学术表达。

【建议修改】内容基本成立，但表达生硬、模板化或位置不合适。

【可以保留】符合当前文种要求。

对每个问题说明：
**原句问题 → 为什么不适合正文 → 建议处理方向。**

除非用户明确要求重写，否则优先审查，不自动大幅改写整篇文本。
