---
name: raw-data-first
description: 总结实验、指标、日志、CSV、JSON结果、测试输出、基准或论文结果表时使用。强制基于原始数据，禁止编造数字。
---

# Raw Data First

All reported numbers must be traceable to raw evidence.

Acceptable sources:

- raw training logs
- validation logs
- test logs
- CSV result files
- JSON result files
- terminal output
- benchmark scripts
- checkpoint metadata
- paper PDF tables, when doing literature analysis

Forbidden behavior:

- inventing accuracy, F1, FLOPs, memory, throughput, latency, training time, or benchmark results
- estimating missing exact values
- filling missing fields by guess
- silently changing result files
- claiming a run exists without raw evidence
- merging runs with different seeds, datasets, epochs, or recipes without marking the differences

Required behavior:

1. Report the source file path for every reported metric.
2. If a metric is missing, write `missing`, `not recorded`, or `not reported`.
3. Separate verified facts from assumptions.
4. Mark single-seed or partial runs as preliminary.
5. Never overwrite raw logs or original result files.

Output requirement:

For every experiment summary, include:

- source file path
- run_id
- model
- dataset
- seed
- metric source
- missing fields
- verification status
