# Language: English source

## Sentence rules

- Use sentence length as a review signal, not a hard limit. 35–40 words is a review signal, not a hard limit.
- Split only when a sentence carries multiple logical functions.
- Preserve a long sentence when its subject, relation and qualification remain clear.
- Do not split a sentence solely because the sentence occupies two or three visual lines.
- Do not split a sentence solely because of visual length.
- Check clusters of overloaded sentences, not isolated sentence length.
- The last sentence of a paragraph often becomes the longest and weakest. Check it explicitly.
- Prefer one core subject-verb proposition per sentence.
- Do not use em dashes as prose punctuation in the polished version unless the user explicitly requests them. Rewrite with commas, parentheses, or shorter sentences instead. Use colons only when they add clear structural value.

## Paragraph rules

- Each paragraph should have one controlling idea followed by support.
- Supporting material may include data, comparison, explanation, consequence, literature, or limitation.
- If a new idea appears, start a new paragraph instead of stacking it onto the old one.
- Use thematic linking, not repetitive `This suggests ...` openings.
- Avoid repeated paragraph-final significance statements.
