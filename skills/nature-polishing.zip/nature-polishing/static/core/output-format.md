# Output format

Default delivery:

Return only the polished text.

Do not expose Skill loading, detected axes, internal review, word-count checks,
or reasoning.

Do not append Revision notes unless the user explicitly requests an explanation
of changes.

If the user explicitly asks for a side-by-side revision or a main-text audit,
provide only that requested material after the polished text.
